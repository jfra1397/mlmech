**Test Case:**  
1. EarlyStoppsing/Shift = True  
   validation-split=0.01  
    * Single Class (A)  
    * Multiclass (B)  
  with 50 epochs  
2. EarlyStopping/Shift = False  
   validation-split=0.1  
    * Single Class (C)  
    * Multiclass (D)   
  with 100 epochs 



